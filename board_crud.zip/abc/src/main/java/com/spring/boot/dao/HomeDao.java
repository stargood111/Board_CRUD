package com.spring.boot.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.spring.boot.dto.HomeDto;
import com.spring.boot.dto.MemberDto;
import com.spring.boot.service.HomeService;


@Mapper
public interface HomeDao {
	

	
	//글 전체리스트
	public List<HomeDto> doStudyList();
	
	//글 수정선택 불러오기
	public HomeDto doStudyListOne(String strbnum);
	
	//게시판 수정
	public void doStudyMod(HomeDto homeDto);
	
	//게시판 삭제
	public Integer doStudyDel(String strbnum);
	//게시판 등록
	public Integer doStudyIns(HomeDto homeDto);
	//게시판 검색
	public List<HomeDto> doSearchList(String strbtitle);
	//로그인
	public MemberDto doLogin(MemberDto memberDto);
	//회원가입
	public Integer doSignUp(MemberDto memerDto);
	
} 
