package com.spring.boot.dto;

import lombok.Data;

@Data
public class HomeDto {
	
	private String bNum;
	private String bName;
	private String bTitle;
	private String bDate;
	private String bContent;
}
