package com.spring.boot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.oracle.wls.shaded.org.apache.xalan.lib.Redirect;
import com.spring.boot.dto.HomeDto;
import com.spring.boot.service.HomeService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class StudyReg {
	
	
	@Autowired
	HomeService homeService;
	
	/*수정*/

	@GetMapping("/modify")
	public String doMod(HttpServletRequest request) {
		
		String strbnum = request.getParameter("bnum");
		
		HomeDto homeDto = new HomeDto();
		
		homeDto = homeService.getStudyListOne(strbnum);
		
		request.setAttribute("homeDto", homeDto);
	
		return "study/study_mod";
	}	
	//게시판 글 수정 참1 거짓 0 확인 intI변수
//	@PostMapping("/modify_exe")
//	public String doModExe(@ModelAttribute HomeDto homeDto) {
//		
//		Integer intI = homeService.getStudyMod(homeDto);
//		
////		return "redirect:home/study_reg"; //url 호출에러
//		return "redirect:/study_reg"; //url 호출
////에러		return "home/study_reg"; //url 호출 //
//	}

	@PostMapping("/modify_exe")
	public String doModExe(@ModelAttribute HomeDto homeDto) {
		
			homeService.getStudyMod(homeDto);
		
	//		return "redirect:home/study_reg"; //url 호출에러
		return "redirect:/study_reg"; //url 호출
	//에러		return "home/study_reg"; //url 호출 //
	}
	//삭제
	@GetMapping("/delete")
	public String doDel(@RequestParam(value ="bnum", defaultValue= "--" )String strbnum) {
		Integer intI = homeService.getStudyDel(strbnum);
		 
		log.info("intI"+intI);
		return "redirect:/study_reg";
	}
	@GetMapping("/insert")
	public String doIns() {
		
		return"study/study_ins";
	}
	//등록
	@PostMapping("/insert_exe")
	public String doInsExe(@ModelAttribute HomeDto homeDto) { 
		
		Integer intI = homeService.getStudyIns(homeDto); 

		return "redirect:/study_reg";
	}
	//검색
	@PostMapping("/search_exe")
	public String doSearch(HttpServletRequest request) { 
			String strbtitle = request.getParameter("btitle");
	
			List<HomeDto> list = new ArrayList<>();
			
			list = homeService.getSearchLiSt(strbtitle);
			
			request.setAttribute("list", list);
	
			//model.addAttribute("list", list);
			
			return "home/search_reg";

		
			
	}
}
