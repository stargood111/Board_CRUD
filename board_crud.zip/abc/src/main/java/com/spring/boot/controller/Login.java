package com.spring.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.boot.dto.HomeDto;
import com.spring.boot.dto.MemberDto;
import com.spring.boot.service.HomeService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import oracle.jdbc.proxy.annotation.Post;

@Controller
public class Login {

	@Autowired
	private HomeService homeService; 
	
	@GetMapping("login") 
	public String login() {
		
		return "login/login";
		
	}
	@PostMapping("login_exe")
	public String dologin(@Valid MemberDto dto, @ModelAttribute MemberDto memberDto, HttpSession session) {
		boolean loginResult = homeService.getLogin(memberDto);
		
		if(loginResult) {
			session.setAttribute("loginName", memberDto.getAName());
			session.setAttribute("loginPw", memberDto.getAPw());
			return "home/home";
		}else {
			return "login/login";
		}
	}
	//회원가입화면
	@GetMapping("member_join") 
	public String doMember_join(){
		
		return "login/member_join";
		
	}
	//회원가입화면
	@PostMapping("signUp") 
	public String doSignUp(@ModelAttribute MemberDto memberDto){
		int signUpResult = homeService.getSignUp(memberDto);
			if(signUpResult >0) {
				return "login/login";
			}else {
				System.out.println("회원가입실패");
				return "login/member_join";
				
			}
			
		}
}
