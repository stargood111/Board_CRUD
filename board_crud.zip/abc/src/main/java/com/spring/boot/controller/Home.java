package com.spring.boot.controller;

import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.spring.boot.dto.HomeDto;
import com.spring.boot.service.HomeService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;


@Controller
@Slf4j
public class Home {

	@Autowired
	 private HomeService homeService; 
	
	@GetMapping("/")
	public String doHome() {
			return "home/home";
		}
	
	@GetMapping("/study_reg")
	public String doStudy_reg(HttpServletRequest request) {
			List<HomeDto> list = new ArrayList<>();
			
			list = homeService.getStudyList();		
			
		
			request.setAttribute("list",list);		
			
			
			//model.addAttribute("list", list);
			
			return "home/study_reg";
		}
}
//	@GetMapping("study_reg")
//	public String doStudy_reg() {
//	
//			
//			return "home/study_reg";
//		}
//}
//System.out.println(list.size());
//System.out.println("0");
//System.out.println("1");
//
//
//System.out.println("2");
//System.out.println("3");
//System.out.println("4");
//System.out.println("5");
//log.info("homeDto");
//for(HomeDto homeDto : list) {
//	log.info(homeDto.getBNum());
//	log.info(homeDto.getBName());
//	log.info(homeDto.getBTitle());
//	log.info(homeDto.getBContent());
//	log.info(homeDto.getBDate());
//	}	
