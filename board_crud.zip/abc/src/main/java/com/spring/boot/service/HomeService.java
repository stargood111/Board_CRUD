package com.spring.boot.service;
 

import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.boot.dao.HomeDao;
import com.spring.boot.dto.HomeDto;
import com.spring.boot.dto.MemberDto;



@Service
public class HomeService {	
	
	
	@Autowired
	private HomeDao homeDao;
	
	public List<HomeDto> getStudyList() {
		
		List<HomeDto> list = new ArrayList<>();
		list = homeDao.doStudyList();
		
		return list;
		
}
	//게시판 하나 선택	
	public HomeDto getStudyListOne(String strbnum) {
		
		HomeDto homeDto = new HomeDto();
		
		homeDto = homeDao.doStudyListOne(strbnum);

		return homeDto;
	}
	//게시판 글 수정 참1 거짓 0 확인 intI변수
//public Integer getStudyMod(HomeDto homeDto) {
//	
//	Integer intI = homeDao.doStudyMod(homeDto);
//		
//		return intI;
//	}
public void getStudyMod(HomeDto homeDto) {
	
	homeDao.doStudyMod(homeDto);
	
	}
 //게시판 글 삭제
public Integer getStudyDel(String strbnum) {
	
	
	Integer intI = homeDao.doStudyDel(strbnum);

	return intI;
	}


//게시판 글 등록


public Integer getStudyIns(HomeDto homeDto) {
	
	Integer intI = homeDao.doStudyIns(homeDto);
		
		return intI;
	}
//회원가입
public Integer getSignUp(MemberDto memberDto) {
	Integer signUpResult = homeDao.doSignUp(memberDto);
	System.out.println(signUpResult);
			return signUpResult;
}

//게시판 글 검색

public List<HomeDto> getSearchLiSt(String strbtitle) {
	System.out.println(strbtitle);
	List<HomeDto> list = new ArrayList<>();
	list = homeDao.doSearchList(strbtitle);
	System.out.println(homeDao);
	return list;
	
	}
	//로그인
	public boolean getLogin(MemberDto memberDto) {
		MemberDto loginMember = homeDao.doLogin(memberDto);
		if(loginMember != null) {
			return true;
		}else {
			return false;
		}
	}
}
//public boolean getLogin(MemberDto memberDto) throws Exception {
//    MemberDto loginMember = homeDao.doLogin(memberDto);
//
//    try {
//        if (loginMember != null) {
//            return true;
//        }
//    } catch (Exception e) {
//        System.out.println("실패");
//        throw e; // 예외를 다시 throw하여 호출자에게 전달합니다.
//    }
//
//    return false; // 로그인 실패 시 false를 반환해야 합니다.
//}
//}
//
//	