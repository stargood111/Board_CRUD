

package com.spring.boot;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@MapperScan(value = "com.spring.boot.dao")
@SpringBootApplication
public class AbcApplication {

	public static void main(String[] args) {	
		SpringApplication.run(AbcApplication.class, args);
	}

}
